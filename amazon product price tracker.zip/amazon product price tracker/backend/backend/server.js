const express = require("express");
const cors = require("cors");
const Database = require("better-sqlite3");

const db = new Database("database.db");

db.prepare(`
  CREATE TABLE IF NOT EXISTS products (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT,
    url TEXT,
    price REAL,
    last_price REAL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  )
`).run();

const app = express();
app.use(cors());
app.use(express.json());

app.post("/add-product", (req, res) => {
  const { name, url, price } = req.body;
  db.prepare(
    "INSERT INTO products (name, url, price, last_price) VALUES (?, ?, ?, ?)"
  ).run(name, url, price, price);
  res.json({ message: "Product added" });
});

app.get("/products", (req, res) => {
  res.json(db.prepare("SELECT * FROM products").all());
});

app.put("/update-price/:id", (req, res) => {
  const { price } = req.body;
  db.prepare(
    "UPDATE products SET last_price = price, price = ? WHERE id = ?"
  ).run(price, req.params.id);
  res.json({ message: "Updated" });
});

app.delete("/delete-product/:id", (req, res) => {
  db.prepare("DELETE FROM products WHERE id = ?").run(req.params.id);
  res.json({ message: "Deleted" });
});

app.listen(3000, () =>
  console.log("✅ Server running on http://localhost:3000")
);
